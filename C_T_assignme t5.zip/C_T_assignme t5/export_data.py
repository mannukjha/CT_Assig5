from pyspark.sql import SparkSession

def export_table(table_name, jdbc_url, db_properties, output_path_base):
    spark = SparkSession.builder \
        .appName(f"Export_{table_name}") \
        .getOrCreate()

    # Read from DB
    df = spark.read.jdbc(url=jdbc_url, table=table_name, properties=db_properties)

    # Write as CSV
    df.write.mode("overwrite").option("header", "true").csv(f"{output_path_base}/{table_name}/csv")

    # Write as Parquet
    df.write.mode("overwrite").parquet(f"{output_path_base}/{table_name}/parquet")

    # Write as Avro
    df.write.mode("overwrite").format("avro").save(f"{output_path_base}/{table_name}/avro")

    spark.stop()

# Example usage
if __name__ == "__main__":
    import sys
    table = sys.argv[1]

    jdbc_url = "jdbc:postgresql://localhost:5432/mydb"
    db_properties = {
        "user": "postgres",
        "password": "yourpassword",
        "driver": "org.postgresql.Driver"
    }
    export_table(table, jdbc_url, db_properties, "/data/exported")
