from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

tables_to_export = ['customers', 'orders', 'products']  # Example tables

with DAG("db_to_files_export",
         start_date=datetime(2024, 1, 1),
         schedule_interval='@daily',  # change to event trigger if needed
         catchup=False) as dag:

    for table in tables_to_export:
        BashOperator(
            task_id=f"export_{table}",
            bash_command=f"spark-submit /path/to/export_data.py {table}"
        )
